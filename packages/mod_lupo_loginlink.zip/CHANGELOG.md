# Changelog

### 3.9.0 (November 01, 2018)
  - Version sync

### 3.8.1 (October 19, 2018)
  - Version sync

### 3.8.0 (October 01, 2018)
  - Version sync

### 3.7.0 (Mai 29, 2018)
  - Version sync

### 3.6.0 (March 21, 2018)
  - Version sync

### 3.2.0 (November 01, 2016)
  - Version sync

### 3.1.0 (Oktober 14, 2016)
  - Initial Version
