# Changelog

### 3.2.0 (November 01, 2016)
  - Version sync

### 3.1.0 (Oktober 14, 2016)
  - Initial Version
