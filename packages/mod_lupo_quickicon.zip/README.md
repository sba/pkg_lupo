mod_lupo_quickicon
===============

Adds LUPO component link to Joomla administrator quick icons
