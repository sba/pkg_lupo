# Changelog

### 3.6.0 (February 21, 2018)
  - make search result link SEO friendly
  - support search by toy-number 

### 3.2.0 (November 01, 2016)
  - search for any words

### 3.1.0 (October 14, 2016)
  - Version sync

### 3.0.0 (August 05, 2016)
  - Version sync

### 2.9.0 (April 19, 2016)
  - Version sync

### 2.8.0 (February 17, 2016)
  - Version sync

### 2.7.0 (January 04, 2016)
  - Version sync

### 2.6.0 (November 19, 2015)
  - version sync

### 2.3.0 (April 28, 2015)
  - description-title added to searchresult text

### 2.0.0 (February 03, 2015)
  - genre, keywords and toy-no added to search query
  - image added to searchresult
  - french language files added (only in github, not in installer)
  
### 1.3.1 (October 15, 2014)
  - plugin-options: Itemid type changed to menuitem
  
### 1.3.0 (October 14, 2014)
  - changelog added
  