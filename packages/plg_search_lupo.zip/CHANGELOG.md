# Changelog

### 2.0.0 (February 03, 2015)

  - genre, keywords and toy-no added to search query
  - image added to searchresult
  - french language files added (only in github, not in installer)
  
### 1.3.1 (October 15, 2014)

  - plugin-options: Itemid type changed to menuitem
  
### 1.3.0 (October 14, 2014)

  - changelog added
  