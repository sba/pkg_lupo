plg_search_lupo
===============

LUPO Joomla Search Plugin
