ALTER TABLE `#__lupo_clients_borrowed` ADD COLUMN `tax_extended` FLOAT DEFAULT 0 NULL AFTER `adrnr`;
