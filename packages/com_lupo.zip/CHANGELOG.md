# Changelog

### 2.0.4 (February 13, 2015)

  - several fixes
  - added admin-button to reprocess xml-file

### 2.0.3 (February 03, 2015)

  - game view updated
  - sql-update fixed
  - xml upload compatibility enhancement

### 2.0.2 (Januar 30, 2015)

  - views updated

### 2.0.1 (Januar 29, 2015)

  - display photo in list (optional)

### 2.0.0 (Januar 28, 2015)

  - listing of agecategories added (view, menutype)
  - listing of genres added (view, menutype)
  - game detail view: output of buttons with document-links
  - some as deprecated marked joomla-functions replaced
  - updated to uikit 2.16.2

### 1.8.0 (Januar 26, 2015)

  - fields added: keywords and genres

### 1.7.0 (November 19, 2014)

  - french translation added

### 1.6.0 (November 06, 2014)

  - some option fields renamed 

### 1.5.0 (October 14, 2014)

  - uikit integration added