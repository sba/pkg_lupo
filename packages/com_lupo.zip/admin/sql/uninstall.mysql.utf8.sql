DROP TABLE IF EXISTS `#__lupo_agecategories`;
DROP TABLE IF EXISTS `#__lupo_categories`;
DROP TABLE IF EXISTS `#__lupo_genres`;
DROP TABLE IF EXISTS `#__lupo_game`;
DROP TABLE IF EXISTS `#__lupo_game_editions`;
DROP TABLE IF EXISTS `#__lupo_game_documents`;
DROP TABLE IF EXISTS `#__lupo_game_genre`;
DROP TABLE IF EXISTS `#__lupo_game_documents`;
DROP TABLE IF EXISTS `#__lupo_game_related`;

