ALTER TABLE `#__lupo_game` ADD COLUMN `id_databauer` INT NULL AFTER `id`;
