ALTER TABLE `#__lupo_genres` ADD COLUMN `alias` CHAR(30) NULL AFTER `genre`;
