ALTER TABLE `#__lupo_agecategories` ADD COLUMN `age_number` VARCHAR(20) NOT NULL AFTER `samples`;
