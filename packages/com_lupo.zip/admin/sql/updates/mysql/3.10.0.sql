ALTER TABLE `#__lupo_game_editions` ADD COLUMN `next_reservation` DATE NULL AFTER `tax`;
