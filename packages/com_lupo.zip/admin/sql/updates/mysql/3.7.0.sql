ALTER TABLE `#__lupo_clients_borrowed` ADD COLUMN `next_reservation` DATE NULL AFTER `reminder_sent`;
