ALTER TABLE `#__lupo_clients_borrowed` ADD COLUMN `next-reservation` DATE NULL AFTER `reminder_sent`;
