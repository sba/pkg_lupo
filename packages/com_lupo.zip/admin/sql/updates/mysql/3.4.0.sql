ALTER TABLE `#__lupo_game` ADD COLUMN `author` VARCHAR(50) NULL AFTER `fabricator`, ADD COLUMN `artist` VARCHAR(50) NULL AFTER `author`;
