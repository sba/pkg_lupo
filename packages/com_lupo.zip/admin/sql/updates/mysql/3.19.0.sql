ALTER TABLE `#__lupo_game` CHANGE `title` `title` VARCHAR(100);

