ALTER TABLE `#__lupo_game` ADD COLUMN `ean` CHAR(13) NULL AFTER `id_databauer`;
