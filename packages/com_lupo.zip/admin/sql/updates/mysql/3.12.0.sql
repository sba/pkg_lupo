ALTER TABLE `#__lupo_clients_borrowed` ADD COLUMN `game_number` CHAR(10) NULL AFTER `edition_id`;
