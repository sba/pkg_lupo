ALTER TABLE `#__lupo_game_editions` ADD COLUMN `content` TEXT NULL AFTER `next_reservation`;

