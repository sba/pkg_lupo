# Changelog

### 3.6.0 (February 21, 2018)
  - Version sync

### 3.2.0 (November 01, 2016)
  - Initial release