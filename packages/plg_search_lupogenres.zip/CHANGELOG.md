# Changelog

### 3.8.0 (October 01, 2018)
  - Version sync

### 3.X.X (2018)
  - Search for exact phrase 

### 3.7.0 (Mai 29, 2018)
  - Version sync

### 3.6.0 (March 21, 2018)
  - Version sync

### 3.2.0 (November 01, 2016)
  - Initial release
