# Changelog

### 3.2.0 (November 01, 2016)
  - Initial release