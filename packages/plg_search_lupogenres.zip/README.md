plg_search_lupogenres
===============

LUPO Joomla Search Plugin for toy genres
