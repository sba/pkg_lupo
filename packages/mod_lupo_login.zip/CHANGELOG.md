# Changelog

### 3.8.0 (October 01, 2018)
  - Version sync

### 3.7.0 (May 29, 2018)
  - do not allow prolongation of reserved games

### 3.6.0 (March 21, 2018)
  - Version sync

### 3.2.0 (November 01, 2016)
  - Version sync

### 3.1.0 (October 14, 2016)
  - redirect after login
  - helper classes added to show/hide text on login/logoff page
  - update prolongation logic

### 3.0.0 (Mai 02, 2016)
  - Initial Version
