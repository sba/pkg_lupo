# Changelog

### 3.1.0 (October 14, 2016)
  - Added possibility to filter genres

### 3.0.0 (August 05, 2016)
  - Version sync

### 2.9.0 (April 19, 2016)
  - Version sync

### 2.8.0 (February 17, 2016)
  - Version sync

### 2.7.0 (January 04, 2016)
  - unnecessary reference removed 

### 2.6.0 (November 19, 2015)
  - Version sync

### 2.3.0 (April 28, 2015)
  - Version sync
  
### 2.0.2 (March 25, 2015)
  - Bugfix php notice
  
### 2.0.1 (February 13, 2015)
  - Added option to hide number badge
  
### 2.0.0 (Januar 28, 2015)
  - Display of 'new games' link (optional)
  - Display of age-categories (optional)
  - Display of genres (optional)

### 1.1.0 (Januar 26, 2015)
  - Badge with number of toys aligned right

### 1.0.1 (October 15, 2014)
  - Install manifest updated to allow updating module

### 1.0.0 (October 14, 2014)
  - Initial Release