mod_lupo_categories
===================

LUPO Joomla Module to display toy categories
