# mod_lupo_login
Joomla Content Plugin to show a random Quote
